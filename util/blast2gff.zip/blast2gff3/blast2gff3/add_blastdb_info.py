#!/usr/bin/env python
import os
import sys
import subprocess
import re
import sqlite3
from optparse import OptionParser
from contextlib import contextmanager

fasta_path = os.path.abspath(sys.argv[1])
fasta_filename = os.path.basename(sys.argv[1])
db_path = os.path.abspath(sys.argv[2])

arr_sseqid = []
with open(fasta_path, 'r') as fp:
    for line in fp:
        line = line.strip()
        if len(line) > 0:
            if line[0] == '>':
                arr_sseqid.append(line[1:])

conn = sqlite3.connect(db_path)
conn.execute("INSERT INTO dbname2dbtype VALUES ('%s', 'Genome Assembly', 'http://gmod-dev.nal.usda.gov:8080/anogla/jbrowse/')"%fasta_filename)

for sseqid in arr_sseqid:
    conn.execute("INSERT INTO sseqid2dbname VALUES ('%s', '%s')"%(sseqid, fasta_filename))
    #print ("INSERT INTO sseqid2dbname VALUES ('%s', '%s')"%(sseqid, fasta_filename))
